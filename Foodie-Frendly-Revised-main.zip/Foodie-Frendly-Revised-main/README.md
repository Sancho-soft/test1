<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>


## About this Project
This Project is for our IT-9 Web Development

## Important
1. always composer install when new PC/Laptop/Environment
2. always copy .env.example as .env
3. if the image won't load: php artisan storage:link

## Creator
- Gilgre Gene Mantilla - Back End
- Emerson Latog - Front End
- Aldren Louie - Document
#   m a m a w  
 #   R e v i s i o n _ C o d e  
 